use php_blog;

create table signup(
id int PRIMARY key AUTO_INCREMENT,
    name varchar(150),
    email varchar(150),
    password varchar(150)
);